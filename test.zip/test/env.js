process.env.NODE_ENV = 'test';
process.env.MONGODB_URI = 'mongodb://admin:password123@localhost:27017/foodshare_test_db?authSource=admin';
process.env.JWT_SECRET = 'test_secret_key_123';
process.env.PORT = '5001';
